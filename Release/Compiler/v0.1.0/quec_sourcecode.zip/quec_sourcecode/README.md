# Unique

# Information
	A programming language is prepared for SourceSpace Studio coding.

# Make
1. `cd UCM` to into Makefile's path. 
2. Use `make` or `mingw32-make` to make file.
3. `./build/quec [workDir] (proName)` to run it.

# More Info
1. [updateLog](./doc/updateLog.md)
2. [grammar](./doc/garmmar.md)

# Release
## Compiler
### v0.1.0
|   Author  |    OS     | app |
|:---------:|:---------:|:---------:|
|   Kkasi666   |    WIN32    | [quec](./Release/Compiler/v0.1.0/win32_quec.zip) |

Welcome to add else version for releasing by yourself.