# Update Log

## [update] v0.0.1 2022.7.6 20:49
1. First update
2. Sopport lexeing and parsing
3. Can make AST, but had't even printed AST node. 

## [update] v0.0.2 2022.7.7 10:46
1. Can show AST, but it isn't nice.

## [update] v0.0.3 2022.7.7 20:56
1. AST is json!
eddd
## [update] v0.0.4 2022.7.10 11:20
1. Sopport neg-number.
2. Fix some bug.

## [update] v0.1.0 2022.7.27 22:06
1. Add assignment statement.
2. The stat statement's grammar is change.
3. Can compiling a source to a byte code.

# Coming Soon
1. Unique Virtual Machine.
2. More...