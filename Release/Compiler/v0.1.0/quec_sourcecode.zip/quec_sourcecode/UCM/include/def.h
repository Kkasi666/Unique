#ifndef UNIQUE_UCM_DEF_H_
#define UNIQUE_UCM_DEF_H_

#define usint unsigned int
#define byte char

#endif // UNIQUE_UCM_DEF_H_