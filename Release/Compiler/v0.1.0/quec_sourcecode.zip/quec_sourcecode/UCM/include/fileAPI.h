#ifndef UNIQUE_UCM_FILEAPI_H_
#define UNIQUE_UCM_FILEAPI_H_

#include <string>

std::string getWorkPath();

#endif // UNIQUE_UCM_FILEAPI_H_